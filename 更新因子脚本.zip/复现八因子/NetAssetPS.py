# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    每股净资产：归属于母公司所有者权益合计比上总股本
    """
    dv.add_field('capital_stk')
    dv.add_field('tot_compreh_inc_parent_comp')
    value = dv.add_formula('NetAssetPS',
                               'tot_compreh_inc_parent_comp/capital_stk',
                               is_quarterly=False, add_data=True)
    return value
