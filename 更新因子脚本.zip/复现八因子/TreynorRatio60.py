# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t1':1, 't2':250, 't3':1, 't4':1, 't5':250, 't6':1, 't7':250, 't8':60} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t1':'收盘价的N日收益','t2':'收益的N日均值','t3':'收盘价的N日收益','t4':'指数收盘价的N日收益','t5':'收盘价N日收益与指数收盘价N日收益的几日协方差','t6':'指数收盘价的N日收益','t7':'指数收盘价的N日收益的几日方差','t8':'特诺雷比率的N日均值'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    60日特诺雷比率，用以衡量投资回报率，属于收益与风险类指标
    """
    import pandas as pd
    from jaqs_fxdayu.data.dataservice import LocalDataService
    dataview_folder = r'../data'
    ds = LocalDataService(fp = dataview_folder)

    # close
    close = dv.get_ts('close')
    # benchmark_close
    bench_close = ds.daily('000300.SH',20170101,20180101)[0]['close'].to_frame()
    bench_close.index = close.index
    benchmark = pd.DataFrame(index=dv.get_ts('open').index)
    for label in dv.get_ts('open').columns:
        benchmark[label] = bench_close['close']


    # numerator
    numerator = (pd.rolling_mean(close.pct_change(params['t1']), params['t2'])*250-0.03)
    # denominator
    beta = pd.rolling_cov(arg1=close.pct_change(params['t3']), arg2=benchmark.pct_change(params['t4']), window=params['t5'])/pd.rolling_var(benchmark.pct_change(params['t6']), params['t7'])

    TR60 = pd.rolling_mean(numerator/beta, params['t8'])
    dv.append_df(TR60, 'TR60')
    value = dv.get_ts('TR60')
    return value
