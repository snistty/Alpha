# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t':6} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t':'几日前的交易量'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    6日量变动速率指标（Volume Rate of Change），以今天的成交量和N天前的成交量比较，通过计算某一段时间内成交量变动的幅度，应用成交量的移动比较来测量成交量运动趋向，达到事先探测成交量供需的强弱，进而分析成交量的发展趋势及其将来是否有转势的意愿，属于成交量的反趋向指标。属于情绪类因子。
    """
    value = dv.add_formula('VROC6_j',
        '((volume/Delay(volume, %s))-1)*100'%params['t'],
        is_quarterly=False, add_data=True)
    return value
