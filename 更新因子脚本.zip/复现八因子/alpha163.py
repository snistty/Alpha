# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t1':1,'t2':20} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t1':'收盘价的几日收益', 't2':'交易量的几日均值'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    这里填写因子的描述信息,详细阐述因子的逻辑，必要时附带公式说明
    复现Alpha163
    对交易日的日收益取负后乘以交易量的20日均值再乘以均价和当日最高价与最低价的差额，最后取排序
    """
    value = dv.add_formula('alpha163',
                         'Rank(((((-Return(close,%s))*Ts_Mean(volume, %s))*vwap)*(high - close)))'%(params['t1'],params['t2']),
                         is_quarterly=False,add_data=True)
    return value
