# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t1':20,'t2':7,'t3':60,'t4':7} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t1':'交易量的多少日均值', 't2':'多少日前的交易量', 't3':'对交易量绝对值的排序', 't4':'多少日前的交易量'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    这里填写因子的描述信息,详细阐述因子的逻辑，必要时附带公式说明
    复现Alpha180
    如果当日交易量小于交易量的20日均值，取对七天前收盘价的绝对值进行60日排序取符号，乘上7日前交易量的正负状态
    否则，取-1*当日交易量
    """
    value = dv.add_formula('alpha180',
                         '(If(Ts_Mean(volume, %s)<volume, ((-Ts_Rank(Abs(Delta(close, %s)), %s))*Sign(Delta(close, %s))), -volume))'%(params['t1'], params['t2'], params['t3'], params['t4']),
                         is_quarterly=False, add_data=True)
    return value
