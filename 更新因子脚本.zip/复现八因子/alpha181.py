# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t1':1,'t2':1,'t3':20,'t4':20, 't5':20, 't6':20, 't7':20} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t1':'N日前收盘价','t2':'N日前收盘价','t3':'收盘价与N日前收盘价比值减一后的几日均值','t4':'指数收盘价的N日均值','t5':'前项数据的N日和','t6':'指数收盘价的N日均值','t7':'指数收盘价与指数收盘价N日均值的差的三次方的几日和'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    复现alpha181
    收盘价比上1日前收盘价后减一减去收盘价与1日前收盘价比值减一的20日均值减去指数收盘价减指数收盘价20日均值差的平方的20日和，除以指数收盘价与指数收盘价20日均值差的三次方的20日和
    """
    import pandas as pd
    from jaqs_fxdayu.data.dataservice import LocalDataService
    dataview_folder = r'../data'
    ds = LocalDataService(fp = dataview_folder)

    # close
    close = dv.get_ts('close')
    # benchmark_close
    bench_close = ds.daily('000300.SH',20170101,20180101)[0]['close'].to_frame()
    bench_close.index = close.index
    benchmark = pd.DataFrame(index=dv.get_ts('open').index)
    for label in dv.get_ts('open').columns:
        benchmark[label] = bench_close['close']
    # numerator
    numerator = pd.rolling_sum((close/close.shift(params['t1'])-1)-pd.rolling_mean((close/close.shift(params['t2'])-1), params['t3'])-(benchmark-pd.rolling_mean(benchmark, params['t4']))**2, params['t5'])
    # denominator
    denominator = pd.rolling_sum((benchmark-pd.rolling_mean(benchmark, params['t6']))**3, params['t7'])

    alpha181 = numerator/denominator
    dv.append_df(alpha181, 'alpha181')
    value = dv.get_ts('alpha181')
    return value