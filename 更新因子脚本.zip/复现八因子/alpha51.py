# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {'t1':1,'t2':1,'t3':1,'t4':1, 't5':12,'t6':1,'t7':1,'t8':1,'t9':1,'t10':12,'t11':1,'t12':1,'t13':1,'t14':1,'t15':12} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {'t1':'N日前最高价','t2':'N日前最低价','t3':'N日前最高价','t4':'N日前最低价','t5':'前项数据N日和','t6':'N日前最高价','t7':'N日前最低价','t8':'N日前最高价','t9':'N日前最低价','t10':'前项数据N日和','t11':'N日前最高价','t12':'N日前最低价','t13':'N日前最高价','t14':'N日前最低价','t15':'前项数据N日和'} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    复现Alpha51
    """
    value = dv.add_formula('alpha51', 
                         '''Ts_Sum(If((high+low)<=(Delay(high, %s)+Delay(low, %s)),0, Max(Abs(high-Delay(high,%s)),Abs(low-Delay(low,%s)))), %s)/(Ts_Sum(If((high+low)<=(Delay(high,%s)+Delay(low,%s)),0,Max(Abs(high-Delay(high,%s)),Abs(low-Delay(low,%s)))),%s)+Ts_Sum(If((high+low)>=(Delay(high,%s)+Delay(low,%s)),0,Max(Abs(high-Delay(high,%s)),Abs(low-Delay(low,%s)))),%s))'''%(params['t1'],params['t2'],params['t3'],params['t4'],params['t5'],params['t6'],params['t7'],params['t8'],params['t9'],params['t10'],params['t11'],params['t12'],params['t13'],params['t14'],params['t15']),
                         is_quarterly=False, add_data=True)
    return value
