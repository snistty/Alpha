# encoding: utf-8 
# 文件需要以utf-8格式编码
# 文件名代表因子名称，需满足命名规范
__author__ = "曾星宇" # 这里填下你的名字
default_params = {} # 这里填写因子参数默认值，比如: {"t1": 10}
params_description = {} # 这里填写因子参数描述信息，比如: {"t1": "并没有用上的参数"}

def run_formula(dv, params=default_params):
    """
    这里填写因子的描述信息,详细阐述因子的逻辑，必要时附带公式说明
    熊市指标减牛市指标
    """
    import pandas as pd
    from jaqs_fxdayu.data.dataservice import LocalDataService
    dataview_folder = r'../data'
    ds = LocalDataService(fp = dataview_folder)

    dv.add_field('BearPower', ds)
    dv.add_field('BullPower', ds)

    value = dv.add_formula('BB',
              'BearPower-BullPower', 
               is_quarterly=False, add_data=True)
    return value
